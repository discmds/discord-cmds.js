// import { install as DiscordMessageComponents } from '@discord-message-components/vue';
// import '@discord-message-components/vue/dist/style.css';

export default ({ Vue }) => {
	// Vue.use(DiscordMessageComponents, {
	// 	avatars: {
	// 		logo: require('./images/logo.png'),
	// 	},
	// 	profiles: {
	// 		user: {
	// 			author: 'User',
	// 			avatar: 'logo',
	// 		},
	// 		bot: {
	// 			author: 'Bot',
	// 			avatar: 'green',
	// 			bot: true,
	// 		},
	// 	},
	// });
};
