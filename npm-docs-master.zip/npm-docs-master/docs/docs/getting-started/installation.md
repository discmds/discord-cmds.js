# Installation

::: warning Note
We only support the support Discord.js version 12.5.3
:::

:::: tabs
::: tab npm
```sh
npm install nuggies@latest
```
:::
::: tab yarn
```sh
yarn add nuggies
```
:::
:::::
